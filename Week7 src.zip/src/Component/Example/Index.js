import React from 'react';

class Exercise extends React.Component {
  render() {
      return <h1>Exercise Tracker</h1>;
  }
};

export default Exercise;