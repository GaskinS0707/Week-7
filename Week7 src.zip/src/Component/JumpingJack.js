import React, {Component} from 'react'

class JumpingJack extends Component {
    constructor (props) {
        super(props);
        this.state = {
            days: 0
        };
    };


render() {

    return(
        <div>
            <h2>Jumping Jacks: {this.state.days}</h2>    
            <button onClick={() => this.setState({days: this.state.days + 1})}> Jumping Jacks Completed</button>
            <button onClick={() => this.setState({days: this.state.days = 0})}> Reset Counter</button>
        </div>
    );
        
}
}

export default JumpingJack;