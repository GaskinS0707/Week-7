import React, { useState} from 'react';

function PushUp () {
    const [days, setDays] = useState(0);

    return (
        <div>
        <h2>Push Ups</h2>
        <button onClick={() => this.setState({days: this.state.days + 1})}> Push Up Completed</button>
        <button onClick={() => this.setState({days: this.state.days = 0})}> Reset Counter </button>
        </div>
    )
}

export default PushUp;