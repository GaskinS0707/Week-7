import JumpingJack from './Component/JumpingJack';
import PushUp from './Component/Push Ups';


function App() {
  return (
    <div>
      <title>Exercise Tracker</title>
      <JumpingJack/>
      <PushUp/>
    </div>
  );
}

export default App;
